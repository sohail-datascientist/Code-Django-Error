from django.apps import AppConfig


class ToeknConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'toekn'
